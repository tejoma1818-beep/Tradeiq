// ── TradeIQ — Stock Quote Proxy ───────────────────────────────────────────────
// Proxies stock quote requests to Finnhub so your API key stays hidden.
// Simple in-memory cache to avoid hammering the API on every page load.

const cache = new Map(); // symbol → { data, timestamp }
const CACHE_TTL = 15000; // 15 seconds

export default async function handler(req, res) {
  if (req.method !== 'GET') {
    return res.status(405).json({ error: 'Method not allowed' });
  }

  const { symbol } = req.query;
  if (!symbol || typeof symbol !== 'string' || symbol.length > 10) {
    return res.status(400).json({ error: 'Invalid symbol' });
  }

  const sym = symbol.toUpperCase().replace(/[^A-Z0-9.]/g, '');

  // Return cached result if fresh
  const cached = cache.get(sym);
  if (cached && Date.now() - cached.timestamp < CACHE_TTL) {
    return res.status(200).json(cached.data);
  }

  try {
    const response = await fetch(
      `https://finnhub.io/api/v1/quote?symbol=${sym}&token=${process.env.FINNHUB_API_KEY}`
    );

    if (!response.ok) {
      return res.status(502).json({ error: 'Stock data unavailable' });
    }

    const data = await response.json();

    // Cache the result
    cache.set(sym, { data, timestamp: Date.now() });

    return res.status(200).json(data);

  } catch (err) {
    console.error('Quote handler error:', err);
    return res.status(500).json({ error: 'Server error' });
  }
}
