// ── TradeIQ — Cosmo AI Proxy ─────────────────────────────────────────────────
// This file runs on YOUR server (Vercel). It holds your OpenAI key hidden from
// users and enforces the educational-only system prompt on every single request.

const COSMO_SYSTEM = `You are Cosmo, a friendly and knowledgeable financial education assistant for TradeIQ, a stock and crypto tracking app. Your role is to help users understand financial concepts, market terminology, how different asset classes work, and general market dynamics.

STRICT RULES — you must always follow these:
1. NEVER give personalized investment advice. Do not tell any user to buy, sell, or hold any specific asset.
2. NEVER predict future prices or say what any stock "will" or "should" do.
3. NEVER recommend specific portfolio allocations for a user's personal money.
4. If someone asks for a personal recommendation (e.g. "should I buy X?"), politely decline and redirect to educational context — explain what factors people generally consider, but make clear you cannot advise them personally.
5. Always remind users you are an educational tool, not a licensed financial advisor.

What you CAN do:
- Explain financial concepts (P/E ratio, market cap, beta, volatility, diversification, etc.)
- Describe what a company does, its sector, and recent general context
- Explain how different markets work (stocks, crypto, commodities, ETFs)
- Discuss historical performance in factual, educational terms
- Help users understand risk concepts in general terms
- Answer "what is" and "how does" questions about finance

Keep responses concise, friendly, and easy to understand. Use plain English. When you use a technical term, briefly define it.`;

export default async function handler(req, res) {
  // Only allow POST requests
  if (req.method !== 'POST') {
    return res.status(405).json({ error: 'Method not allowed' });
  }

  // Basic validation
  const { messages } = req.body;
  if (!messages || !Array.isArray(messages)) {
    return res.status(400).json({ error: 'Invalid request — messages array required' });
  }

  // Limit conversation history to last 20 messages (controls cost + context size)
  const recentMessages = messages.slice(-20);

  // Block messages that are suspiciously long (prompt injection protection)
  for (const msg of recentMessages) {
    if (typeof msg.content === 'string' && msg.content.length > 1000) {
      return res.status(400).json({ error: 'Message too long' });
    }
  }

  try {
    const response = await fetch('https://api.openai.com/v1/chat/completions', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        // OPENAI_API_KEY is stored in Vercel environment variables — never visible to users
        'Authorization': `Bearer ${process.env.OPENAI_API_KEY}`
      },
      body: JSON.stringify({
        model: 'gpt-4o-mini',
        messages: [
          { role: 'system', content: COSMO_SYSTEM },
          ...recentMessages
        ],
        max_tokens: 600,
        temperature: 0.7
      })
    });

    if (!response.ok) {
      const err = await response.json().catch(() => ({}));
      console.error('OpenAI error:', err);
      return res.status(502).json({ error: 'AI service error. Please try again.' });
    }

    const data = await response.json();
    const reply = data.choices?.[0]?.message?.content || 'Sorry, I had trouble with that response.';

    return res.status(200).json({ reply });

  } catch (err) {
    console.error('Cosmo handler error:', err);
    return res.status(500).json({ error: 'Server error. Please try again.' });
  }
}
